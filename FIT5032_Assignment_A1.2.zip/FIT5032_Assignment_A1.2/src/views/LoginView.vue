<template>
  <div class="auth-bg">
    <div class="signup-card">
      <h2 class="fw-bold mb-4 text-center">Login</h2>

      <form @submit.prevent="onLogin" novalidate>
        <!-- Email -->
        <div class="mb-3">
          <label class="form-label">Email</label>
          <input type="email" class="form-control" v-model.trim="email" @input="validateEmailInput"
            :class="{ 'is-invalid': err.email }" placeholder="you@example.com" required />
          <div class="invalid-feedback" v-if="err.email">{{ err.email }}</div>
        </div>

        <!-- Password -->
        <div class="mb-3">
          <label class="form-label">Password</label>
          <div class="input-group">
            <input :type="showPwd ? 'text' : 'password'" class="form-control" v-model="password"
              @input="validatePassword" :class="{ 'is-invalid': err.password }" required />
            <button type="button" class="btn btn-outline-secondary" @click="showPwd = !showPwd">
              <i :class="showPwd ? 'bi bi-eye-slash' : 'bi bi-eye'"></i>
            </button>
            <div class="invalid-feedback" v-if="err.password">{{ err.password }}</div>
          </div>
        </div>

        <!-- Submit -->
        <button class="btn-primary-custom" type="submit">Sign in</button>
        <p v-if="okMsg" class="text-success mt-2">{{ okMsg }}</p>

        <p class="text-center mt-3">
          Don't have an account?
          <router-link to="/register">Create one</router-link>
        </p>
      </form>
    </div>
  </div>
</template>


<script setup>
import { ref, reactive } from 'vue'
import { useRouter } from 'vue-router'

// ⬇️ 使用你在 src/firebase/config.js 中导出的实例
import { auth } from '@/firebase/config'
import { signInWithEmailAndPassword } from 'firebase/auth'
import { fetchUserRole } from '@/services/authService'

const router = useRouter()

// 表单状态
const email = ref('')
const password = ref('')
const err = reactive({ email: '', password: '' })
const okMsg = ref('')
const showPwd = ref(false)

// 基础校验（保持你现有的体验）
const validateEmailInput = () => {
  err.email = !email.value
    ? 'Email is required.'
    : !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value)
      ? 'Please enter a valid email.'
      : ''
}
const validatePassword = () => {
  err.password = !password.value
    ? 'Password is required.'
    : password.value.length < 8
      ? 'Password must be at least 8 characters.'
      : ''
}

// 把 Firebase 报错转换为友好的提示
function mapAuthError(code) {
  switch (code) {
    case 'auth/invalid-email': return 'Please enter a valid email.'
    case 'auth/user-disabled': return 'This account has been disabled.'
    case 'auth/user-not-found': return 'No account found with this email.'
    case 'auth/wrong-password':
    case 'auth/invalid-credential': return 'Invalid email or password.'
    case 'auth/too-many-requests': return 'Too many attempts. Please try again later.'
    default: return 'Sign in failed. Please try again.'
  }
}

async function onLogin() {
  // 清空错误并做前端校验
  err.email = err.password = ''
  validateEmailInput()
  validatePassword()
  if (err.email || err.password) return

  try {
    // 1) Firebase Auth 登录
    const { user } = await signInWithEmailAndPassword(auth, email.value, password.value)

    // 2) 获取角色（离线容错：失败时默认 user）
    const role = await fetchUserRole(user.uid).catch(() => 'user')

    okMsg.value = 'Login successful!'

    // 3) 按角色跳转：admin -> /profile, user -> /home
    setTimeout(() => {
      if (role === 'admin') router.push('/profile')
      else router.push('/home')
    }, 400)
  } catch (e) {
    // 根据错误类型提示
    const msg = mapAuthError(e?.code)
    // 统一放在 password 的错误位（也可以分流到 email 位）
    err.password = msg
    okMsg.value = ''
  }
}
</script>


<style scoped>
/* 背景 */
.auth-bg {
  --nav-h: 64px;
  min-height: calc(100vh - var(--nav-h));
  display: flex;
  align-items: flex-start;
  align-items: center;
  justify-content: center;
  padding: 84px 24px 24px;
  background: linear-gradient(135deg, #ffd8e6, #ffb6c1);
}

/* 卡片 */
.signup-card {
  width: 100%;
  max-width: 520px;
  min-height: min-content;
  max-height: calc(100vh - 48px);
  overflow-y: auto;
  background: #fff;
  border-radius: 16px;
  box-shadow: 0 16px 40px rgba(0, 0, 0, .12);
  padding: 32px 28px;
}

.signup-card h2 {
  text-align: center;
  font-size: 1.6rem;
  font-weight: 800;
  margin-bottom: 18px;
  color: #262c67;
}

/* 表单宽度（让输入框看起来不那么长） */
.signup-card form {
  max-width: 360px;
  margin: 0 auto;
}

/* 输入框：统一高度与圆角 */
.form-control {
  width: 100%;
  height: 50px;
  padding: 10px 14px;
  border-radius: 10px !important;
  font-size: 1rem;
  box-shadow: none;
}

/* 输入组中的输入框圆角处理 */
.input-group .form-control {
  border-top-right-radius: 0 !important;
  border-bottom-right-radius: 0 !important;
}

/* 输入组中的按钮圆角处理 */
.input-group .btn {
  border-top-right-radius: 10px !important;
  border-bottom-right-radius: 10px !important;
  height: 50px;
}

/* 自定义密码可见性按钮样式 */
.input-group .btn-outline-secondary {
  border: 1px solid #ced4da !important;
  border-left: none !important;
  color: #6c757d !important;
  background-color: transparent !important;
  margin-left: -1px;
  /* 确保边框重叠 */
}

.input-group .btn-outline-secondary:hover {
  background-color: #f8f9fa !important;
  border-color: #ced4da !important;
  color: #6c757d !important;
}

/* 在验证错误状态下保持按钮样式 */
.input-group .form-control.is-invalid+.btn-outline-secondary {
  border-color: #dc3545 !important;
  border-left: none !important;
}

/* 确保验证状态下的圆角 */
.form-control.is-invalid {
  border-radius: 10px !important;
}

.input-group .form-control.is-invalid {
  border-top-right-radius: 0 !important;
  border-bottom-right-radius: 0 !important;
}

/* 修改所有输入框的 placeholder 颜色 */
.form-control::placeholder {
  color: #8a8a8a;
  opacity: 1;
}

/* 输入框 */
.form-control.is-invalid {
  border-color: #dc3545;
}

.invalid-feedback {
  color: #dc3545;
  font-size: .9rem;
}

/* 星号 */
.form-label::after {
  content: " *";
  color: #dc3545;
  font-weight: 300;
}

/* 按钮 */
.btn-primary-custom {
  display: block;
  min-width: 160px;
  padding: 10px 24px;
  margin: 16px auto 0;
  border-radius: 10px;
  background: #262c67;
  color: #fff;
  border: none;
  font-weight: 700;
  font-size: 1rem;
  cursor: pointer;
}

.btn-primary-custom:hover {
  background: #1a1f4d;
}
</style>
