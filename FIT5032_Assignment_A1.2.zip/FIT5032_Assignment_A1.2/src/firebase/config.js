// src/config.js
import { initializeApp } from 'firebase/app'
import { getAuth, connectAuthEmulator } from 'firebase/auth'
import { getFirestore, connectFirestoreEmulator } from 'firebase/firestore'

// 从 Firebase 控制台复制的完整配置
const firebaseConfig = {
  apiKey: "AIzaSyCSXcm692gMizSGUjGRSvjmGHiriYSJ1aM",
  authDomain: "she-93a56.firebaseapp.com",
  projectId: "she-93a56",
  storageBucket: "she-93a56.firebasestorage.app",
  messagingSenderId: "102206821629",
  appId: "1:102206821629:web:d41ee885de20cc18095a94"
};

// 初始化
const app = initializeApp(firebaseConfig)

// 初始化 Authentication 和 Firestore
const auth = getAuth(app)
const db = getFirestore(app)

// 在本地开发时，自动连接到 Firebase Emulator（避免被网络拦截导致离线报错）
try {
  const isLocal = typeof window !== 'undefined' && (
    window.location.hostname === 'localhost' ||
    window.location.hostname === '127.0.0.1'
  )
  if (isLocal) {
    // 端口与 firebase_emulator/firebase.json 保持一致（常见缺省：Auth 9099，Firestore 8080）
    connectAuthEmulator(auth, 'http://127.0.0.1:9099', { disableWarnings: true })
    connectFirestoreEmulator(db, '127.0.0.1', 8080)
  }
} catch { /* no-op */ }

export { auth, db }
