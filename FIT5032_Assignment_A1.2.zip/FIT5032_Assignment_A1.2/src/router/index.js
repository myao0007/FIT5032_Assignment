// src/router/index.js
import { createRouter, createWebHistory } from 'vue-router'

import HomeView from '@/views/HomeView.vue'
import LoginView from '@/views/LoginView.vue'
import RegisterView from '@/views/RegisterView.vue'
import ProfileView from '@/views/ProfileView.vue'

import { getCachedUser, fetchUserRole } from '@/services/authService'
import { auth } from '@/firebase/config'
import { onAuthStateChanged } from 'firebase/auth'

// === 关键修复：确保先等 Firebase 恢复会话，再做路由判断 ===
let authReadyPromise
if (!authReadyPromise) {
  authReadyPromise = new Promise((resolve) => {
    const off = onAuthStateChanged(auth, () => {
      off()
      resolve()
    })
  })
}

const router = createRouter({
  history: createWebHistory(), // 如果你项目有 base 路径，这里记得加：createWebHistory(import.meta.env.BASE_URL)
  routes: [
    { path: '/', redirect: '/home' },
    { path: '/home', name: 'home', component: HomeView },

    { path: '/login', name: 'login', component: LoginView, meta: { guestOnly: true } },
    { path: '/register', name: 'register', component: RegisterView, meta: { guestOnly: true } },

    // 仅管理员可见
    { path: '/profile', name: 'profile', component: ProfileView, meta: { requiresAuth: true, requiresAdmin: true } },

    { path: '/:pathMatch(.*)*', redirect: '/home' }
  ]
})

/** 路由守卫：鉴权 + 角色 */
router.beforeEach(async (to, from, next) => {
  // 先等 Firebase 恢复当前用户
  await authReadyPromise

  const cached = getCachedUser()
  const current = auth.currentUser
  const isLoggedIn = !!current

  // 如果本地缓存存在但实际未登录，清理过期缓存，避免误判
  if (!current && cached) {
    try { localStorage.removeItem('currentUser') } catch (e) {}
  }

  // 仅游客可访问（login / register）
  if (to.meta.guestOnly && isLoggedIn) {
    // 已登录时访问 login/register，按角色分流
    const role = (cached && cached.uid === current.uid)
      ? cached.role
      : await fetchUserRole(current.uid)
    return next(role === 'admin' ? { name: 'profile' } : { name: 'home' })
  }

  // 需要登录
  if (to.meta.requiresAuth && !isLoggedIn) {
    return next({ name: 'login', query: { redirect: to.fullPath } })
  }

  // 需要管理员
  if (to.meta.requiresAdmin) {
    const role = isLoggedIn
      ? ((cached && cached.uid === current.uid) ? cached.role : await fetchUserRole(current.uid))
      : 'user'
    if (role !== 'admin') return next({ name: 'home' })
  }

  next()
})

export default router
